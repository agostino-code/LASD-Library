#include "stackvec.hpp"

namespace lasd {

/* ************************************************************************** */

    template<typename Data>
    StackVec<Data>::StackVec() {
        vector=new Vector<Data>(10);
        stacksize=0;
        size=10;

    }

    template<typename Data>
    StackVec<Data>::StackVec(const LinearContainer<Data> & lc){
        stacksize = lc.Size();
        vector=new Vector<Data>(lc);
    }

    template<typename Data>
    StackVec<Data>::StackVec(const StackVec<Data> & stackVec) {
        vector=new Vector<Data>(stackVec.size);
        for(unsigned long i=0;i<stackVec.size;i++){
            vector->operator[](i)=stackVec.vector->operator[](i);
        }
        stacksize = stackVec.Size();
    }

    template<typename Data>
    StackVec<Data>::StackVec(StackVec<Data>&& stackVec) noexcept {
        vector->operator=(*stackVec.vector);
        size=stackVec.size;
        stacksize=stackVec.stacksize;
    }

    template<typename Data>
    StackVec<Data> &StackVec<Data>::operator=(const StackVec<Data> & stackVec) {
        vector->operator=(*stackVec.vector);
        size=stackVec.size;
        stacksize=stackVec.stacksize;
        return *this;
    }

    template<typename Data>
    StackVec<Data> &StackVec<Data>::operator=(StackVec && stackVec) noexcept {
        std::swap(vector,stackVec.vector);
        std::swap(size, stackVec.size);
        std::swap(stacksize,stackVec.stacksize);
        return *this;
    }

    template<typename Data>
    bool StackVec<Data>::operator==(const StackVec & stackVec) const noexcept {
        if (stacksize==stackVec.stacksize){
            for (unsigned long i=0; i<stacksize; i++){
                if(vector->operator[](i) != stackVec.vector->operator[](i)){
                    return false;
                }
            }
            return true;
        }else{
            return false;
        }
    }

    template<typename Data>
    bool StackVec<Data>::operator!=(const StackVec & stackVec) const noexcept {
        return !(*this == stackVec);
    }

    template<typename Data>
    const Data &StackVec<Data>::Top() const {
        if (Empty()) { throw std::length_error("The Stack is empty"); }
        return vector->operator[](stacksize-1);
    }

    template<typename Data>
    Data &StackVec<Data>::Top() {
        if (Empty()) { throw std::length_error("The Stack is empty"); }

        return vector->operator[](stacksize-1);
    }

    template<typename Data>
    void StackVec<Data>::Pop() {
        if (Empty()) { throw std::length_error("The Stack is empty"); }
        else {
            stacksize--;
        }
        if(size >10 && stacksize<(size/1,5)) { Reduce();}
    }

    template<typename Data>
    Data StackVec<Data>::TopNPop() {
        if (Empty()) { throw std::length_error("The Stack is empty");}
        else{
            Data temp=Top();
            Pop();
            return temp;}
    }

    template<typename Data>
    void StackVec<Data>::Push(const Data & newValue) noexcept {
        if (stacksize == size) { Expand(); }
            vector->operator[](stacksize) = newValue;
            stacksize++;
    }

    template<typename Data>
    void StackVec<Data>::Push(Data && newValue) noexcept {
        if (stacksize == size) { Expand(); }
            vector->operator[](stacksize) = std::move(newValue);
            stacksize++;
    }

    template<typename Data>
    bool StackVec<Data>::Empty() const noexcept {
        return (stacksize==0);
    }

    template<typename Data>
    unsigned long StackVec<Data>::Size() const noexcept {
        return stacksize;
    }

    template<typename Data>
    void StackVec<Data>::Clear() {
        delete vector;
        vector = new Vector<Data>(10);
        stacksize=0;
    }

    template<typename Data>
    void StackVec<Data>::Expand() {
        vector->Resize((size * 1,5));
    }

    template<typename Data>
    void StackVec<Data>::Reduce() {
        vector->Resize((size / 1,5));
    }

    template<typename Data>
    StackVec<Data>::~StackVec() {
        delete vector;
    }




/* ************************************************************************** */

}
